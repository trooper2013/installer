import com.magnet.tools.cli.core.CoreConstants
import com.magnet.tools.cli.mob.MobConstants
import com.magnet.tools.utils.AnsiHelper

// Magnet configuration override file
// You can override default magnet configuration value in this config groovy file

/**
 *  Values are Strings,
 * rather than command instance in order to prevent loading all classes and fasten tool startup
 */
commands = [
    (CoreConstants.ALIAS_COMMAND): [class: "com.magnet.tools.cli.base.AliasCommand"],
    (CoreConstants.UNALIAS_COMMAND): [class: "com.magnet.tools.cli.base.UnaliasCommand"],
    (CoreConstants.CLEAR_COMMAND): [class: "com.magnet.tools.cli.base.ClearCommand"],
    (CoreConstants.EXIT_COMMAND): [class: "com.magnet.tools.cli.base.ExitCommand", aliases: [CoreConstants.EXIT_COMMAND_ALIAS, CoreConstants.QUIT_COMMAND]],
    (CoreConstants.HELP_COMMAND): [class: "com.magnet.tools.cli.base.HelpCommand", aliases: [CoreConstants.HELP_COMMAND_ALIAS]],
    (CoreConstants.TOPIC_COMMAND): [class: "com.magnet.tools.cli.base.TopicCommand", aliases: [CoreConstants.TOPIC_COMMAND_ALIAS], hidden:true], // overridden to be hidden
    (CoreConstants.HISTORY_COMMAND): [class: "com.magnet.tools.cli.base.HistoryCommand", aliases: [CoreConstants.HISTORY_COMMAND_ALIAS]],
    (CoreConstants.SET_COMMAND): [class: "com.magnet.tools.cli.base.SetCommand", hidden:true], // overridden to be hidden
    (CoreConstants.VALIDATE_COMMAND): [class: "com.magnet.tools.cli.base.ValidateCommand", hidden:true], // overridedn to be hidden
    (CoreConstants.EXEC_COMMAND): [class: "com.magnet.tools.cli.base.ExecCommand", aliases: [CoreConstants.EXEC_COMMAND_ALIAS], hidden:true], // overridden to be hidden
    (CoreConstants.DIAGNOSTICS_COMMAND): [class: "com.magnet.tools.cli.base.DiagnosticsCommand", hidden:true], // overridden to be hidden
    (CoreConstants.REGISTER_COMMAND): [class: "com.magnet.tools.cli.base.RegisterCommand", hidden:true], // WON-7466
    (CoreConstants.RUN_COMMAND): [class: "com.magnet.tools.cli.base.RunCommand", aliases: [CoreConstants.RUN_COMMAND_ALIAS], hidden:true],  // overridden to be hidden
    (CoreConstants.OPEN_COMMAND): [class: "com.magnet.tools.cli.base.OpenCommand", hidden:true] // use the base open command implementation
]

prompt = AnsiHelper.green(MobConstants.PROMPT)

skipValidation = true

beforeHooks = [
    1: "com.magnet.tools.cli.mob.GenCommandGreetingsBeforeHook"
]

