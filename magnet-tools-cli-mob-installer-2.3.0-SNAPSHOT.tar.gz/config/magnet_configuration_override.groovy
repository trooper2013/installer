import com.magnet.tools.cli.core.CoreConstants
import com.magnet.tools.cli.mob.MobConstants
import com.magnet.tools.utils.AnsiHelper

// Magnet configuration override file
// You can override default magnet configuration value in this config groovy file

/**
 *  Values are Strings,
 * rather than command instance in order to prevent loading all classes and fasten tool startup
 */
commands = [
    // use the base open command implementation
    (CoreConstants.OPEN_COMMAND): [class: "com.magnet.tools.cli.base.OpenCommand"],
]

prompt = AnsiHelper.green(MobConstants.PROMPT)

skipValidation = true

beforeHooks = [
    1: "com.magnet.tools.cli.mob.GenCommandGreetingsBeforeHook"
]

